# ==========================================
# FILE: src/entities.py
# ==========================================
import pygame
import random
import math
from src.config import (
    BALL_RADIUS, BASE_BALL_SPEED, WEAPONS, ABILITIES,
    FONT_SMALL, NEON_RED, NEON_CYAN, NEON_ORANGE, NEON_YELLOW, NEON_GREEN
)


class Projectile:
    """Класс для снарядов (пули дробовика, ракеты, бумеранги)"""
    def __init__(self, x, y, vx, vy, color, damage, owner, is_rocket=False, is_boomerang=False, sprite_manager=None):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.radius = 5 if not is_rocket else 8
        if is_boomerang:
            self.radius = 10
        self.color = color
        self.damage = damage
        self.owner = owner
        self.is_rocket = is_rocket
        self.is_boomerang = is_boomerang
        self.sprites = sprite_manager
        self.alive = True

        self.life_timer = 0.0
        self.returning = False
        self.spin_angle = 0.0

    def update(self, dt, target_ball=None):
        if self.is_rocket and target_ball:
            dx = target_ball.x - self.x
            dy = target_ball.y - self.y
            dist = math.hypot(dx, dy)
            if dist > 0:
                target_vx = (dx / dist) * 5.5
                target_vy = (dy / dist) * 5.5
                self.vx += (target_vx - self.vx) * 0.06
                self.vy += (target_vy - self.vy) * 0.06

        elif self.is_boomerang:
            self.life_timer += dt
            self.spin_angle += dt * 720  # Вращение бумеранга
            if self.life_timer > 1.1 and not self.returning:
                self.returning = True

            if self.returning:
                dx = self.owner.x - self.x
                dy = self.owner.y - self.y
                dist = math.hypot(dx, dy)
                if dist > 12:
                    self.vx = (dx / dist) * 8.5
                    self.vy = (dy / dist) * 8.5
                else:
                    self.alive = False

        self.x += self.vx
        self.y += self.vy

    def draw(self, surface):
        if self.is_rocket:
            img = self.sprites.get("rocket") if self.sprites else None
            if img:
                # Угол полета в градусах (в Pygame поворот против часовой стрелки)
                angle_deg = -math.degrees(math.atan2(self.vy, self.vx))
                rot_img = pygame.transform.rotate(img, angle_deg)
                rect = rot_img.get_rect(center=(int(self.x), int(self.y)))
                surface.blit(rot_img, rect)
                return

        elif self.is_boomerang:
            img = self.sprites.get("boomerang") if self.sprites else None
            if img:
                rot_img = pygame.transform.rotate(img, self.spin_angle)
                rect = rot_img.get_rect(center=(int(self.x), int(self.y)))
                surface.blit(rot_img, rect)
                return
            pygame.draw.circle(surface, self.color, (int(self.x), int(self.y)), self.radius, 2)
            return

        else:
            img = self.sprites.get("bullet") if self.sprites else None
            if img:
                rect = img.get_rect(center=(int(self.x), int(self.y)))
                surface.blit(img, rect)
                return

        pygame.draw.circle(surface, self.color, (int(self.x), int(self.y)), self.radius)
        pygame.draw.circle(surface, (255, 255, 255), (int(self.x), int(self.y)), max(1, self.radius // 2))


class Ball:
    def __init__(self, x, y, text, color, color_index=0, sprite_manager=None):
        self.x = x
        self.y = y
        self.radius = BALL_RADIUS
        self.text = text
        self.color = color
        self.color_index = color_index
        self.sprites = sprite_manager
        self.hp = 100
        self.max_hp = 100

        self.archetype = random.choice(["WEAPON", "ABILITY"])
        if self.archetype == "WEAPON":
            self.weapon = random.choice(list(WEAPONS.keys()))
            self.ability = None
        else:
            self.weapon = None
            self.ability = random.choice(list(ABILITIES.keys()))

        angle = random.uniform(0, 2 * math.pi)
        self.vx = math.cos(angle) * BASE_BALL_SPEED
        self.vy = math.sin(angle) * BASE_BALL_SPEED

        self.weapon_timer = random.uniform(0, 1.0)
        self.ability_timer = random.uniform(0, 1.0)
        self.anim_timer = 0.0

        # Эффекты
        self.shield_active = (self.ability == "Shield")
        self.ghost_timer = 0.0
        self.frozen_timer = 0.0

        # Визуал и логика оружия
        self.saw_angle = 0.0
        self.laser_target_line = None
        self.tesla_targets = []
        self.fire_trails = []
        self.ice_trails = []
        self.mine_attached = None
        self.mine_timer = 0.0

        self.trail_history = []
        self.max_trail_len = 8

    def update_physics(self, dt, arena_rect):
        self.anim_timer += dt
        current_speed_modifier = 0.5 if self.frozen_timer > 0 else 1.0
        if self.frozen_timer > 0:
            self.frozen_timer -= dt
        if self.ability == "HeavyWeight":
            current_speed_modifier *= 0.8

        # Плавное затухание сверхскорости после рывка (Dash)
        speed = math.hypot(self.vx, self.vy)
        if speed > BASE_BALL_SPEED * 1.1:
            self.vx *= 0.96
            self.vy *= 0.96

        self.x += self.vx * current_speed_modifier
        self.y += self.vy * current_speed_modifier

        self.trail_history.append((self.x, self.y))
        if len(self.trail_history) > self.max_trail_len:
            self.trail_history.pop(0)

        # Огненный след (FireTrail)
        if self.weapon == "FireTrail":
            self.ability_timer += dt
            if self.ability_timer > 0.18:
                self.fire_trails.append({"x": self.x, "y": self.y, "life": 2.2})
                self.ability_timer = 0

        # Ледяной пол (IceFloor)
        if self.ability == "IceFloor":
            self.ability_timer += dt
            if self.ability_timer > 0.35:
                self.ice_trails.append({"x": self.x, "y": self.y, "life": 3.0})
                self.ability_timer = 0

        for ft in self.fire_trails[:]:
            ft["life"] -= dt
            if ft["life"] <= 0:
                self.fire_trails.remove(ft)

        for it in self.ice_trails[:]:
            it["life"] -= dt
            if it["life"] <= 0:
                self.ice_trails.remove(it)

        # Отскоки от стен
        hit_wall = False
        if self.x - self.radius < arena_rect.left:
            self.x = arena_rect.left + self.radius
            self.vx = abs(self.vx)
            hit_wall = True
        elif self.x + self.radius > arena_rect.right:
            self.x = arena_rect.right - self.radius
            self.vx = -abs(self.vx)
            hit_wall = True

        if self.y - self.radius < arena_rect.top:
            self.y = arena_rect.top + self.radius
            self.vy = abs(self.vy)
            hit_wall = True
        elif self.y + self.radius > arena_rect.bottom:
            self.y = arena_rect.bottom - self.radius
            self.vy = -abs(self.vy)
            hit_wall = True

        if hit_wall and self.weapon == "Shotgun" and self.weapon_timer > 1.0:
            self.weapon_timer = -0.5

    def update_logic(self, dt, all_balls, projectiles, arena_rect=None):
        if self.hp <= 0:
            if self.ability == "Kamikaze":
                self.ability = None
                for b in all_balls:
                    if b != self and b.hp > 0:
                        if math.hypot(b.x - self.x, b.y - self.y) < 250:
                            b.take_damage(35, self)
            return

        if self.weapon == "Saws":
            self.saw_angle += dt * 5

        # Пассивные способности
        if self.ability == "Regen" and self.hp < self.max_hp:
            self.hp = min(self.max_hp, self.hp + dt * 2.5)

        if self.ability == "GhostForm" and self.hp < 35 and self.ghost_timer <= 0:
            self.ghost_timer = 3.5
        if self.ghost_timer > 0:
            self.ghost_timer -= dt

        if self.ability == "Shield" and not self.shield_active:
            self.ability_timer += dt
            if self.ability_timer >= 6.5:
                self.shield_active = True
                self.ability_timer = 0

        # Рывок (Dash)
        if self.ability == "Dash":
            self.ability_timer += dt
            if self.ability_timer >= 3.0:
                enemies = [b for b in all_balls if b != self and b.hp > 0]
                if enemies:
                    target = min(enemies, key=lambda b: math.hypot(b.x - self.x, b.y - self.y))
                    ang = math.atan2(target.y - self.y, target.x - self.x)
                    self.vx = math.cos(ang) * BASE_BALL_SPEED * 2.4
                    self.vy = math.sin(ang) * BASE_BALL_SPEED * 2.4
                self.ability_timer = 0

        # Магнит (Magnet) — притягивает врагов
        if self.ability == "Magnet":
            for b in all_balls:
                if b != self and b.hp > 0:
                    dx, dy = self.x - b.x, self.y - b.y
                    dist = math.hypot(dx, dy)
                    if 40 < dist < 240:
                        b.vx += (dx / dist) * 12 * dt
                        b.vy += (dy / dist) * 12 * dt

        # Телепорт (Teleport)
        if self.ability == "Teleport" and arena_rect:
            self.ability_timer += dt
            if self.ability_timer >= 4.5:
                self.x = random.randint(arena_rect.left + 45, arena_rect.right - 45)
                self.y = random.randint(arena_rect.top + 45, arena_rect.bottom - 45)
                self.ability_timer = 0

        # Урон от огня и замедление от льда врагов
        for b in all_balls:
            if b != self and b.hp > 0:
                if b.weapon == "FireTrail":
                    for ft in b.fire_trails:
                        if math.hypot(self.x - ft["x"], self.y - ft["y"]) < self.radius + 12:
                            self.take_damage(dt * 15, b)
                if b.ability == "IceFloor":
                    for it in b.ice_trails:
                        if math.hypot(self.x - it["x"], self.y - it["y"]) < self.radius + 14:
                            self.frozen_timer = 0.5

        # Урон пилами (Saws)
        if self.weapon == "Saws":
            for b in all_balls:
                if b != self and b.hp > 0:
                    if math.hypot(b.x - self.x, b.y - self.y) < self.radius * 2 + 20:
                        b.take_damage(dt * 12, self)

        # Таймер мины (StickyBomb)
        if self.mine_attached:
            self.mine_timer += dt
            if self.mine_timer >= 2.0:
                if self.mine_attached.hp > 0:
                    self.mine_attached.take_damage(24, self)
                for b in all_balls:
                    if b != self.mine_attached and b.hp > 0:
                        if math.hypot(b.x - self.mine_attached.x, b.y - self.mine_attached.y) < 120:
                            b.take_damage(12, self)
                self.mine_attached = None
                self.mine_timer = 0.0

        if self.weapon:
            self.weapon_timer += dt
            self.trigger_weapon(dt, projectiles, all_balls)

    def trigger_weapon(self, dt, projectiles, all_balls):
        enemies = [b for b in all_balls if b != self and b.hp > 0]
        if not enemies:
            return
        closest_enemy = min(enemies, key=lambda b: math.hypot(b.x - self.x, b.y - self.y))
        dist = math.hypot(closest_enemy.x - self.x, closest_enemy.y - self.y)
        self.laser_target_line = None
        self.tesla_targets.clear()

        if self.weapon == "Shotgun" and self.weapon_timer < -0.1:
            for _ in range(6):
                ang = random.uniform(0, 2 * math.pi)
                projectiles.append(Projectile(
                    self.x, self.y, math.cos(ang) * 5.5, math.sin(ang) * 5.5,
                    NEON_ORANGE, 4, self, sprite_manager=self.sprites
                ))
            self.weapon_timer = 0.0

        elif self.weapon == "Laser" and self.weapon_timer >= 2.5:
            if dist < 350:
                closest_enemy.take_damage(10, self)
                self.laser_target_line = (closest_enemy.x, closest_enemy.y)
            self.weapon_timer = 0.0

        elif self.weapon == "Rocket" and self.weapon_timer >= 3.5:
            dx, dy = closest_enemy.x - self.x, closest_enemy.y - self.y
            length = math.hypot(dx, dy)
            if length > 0:
                projectiles.append(Projectile(
                    self.x, self.y, (dx / length) * 3.5, (dy / length) * 3.5,
                    NEON_CYAN, 9, self, is_rocket=True, sprite_manager=self.sprites
                ))
            self.weapon_timer = 0.0

        elif self.weapon == "Tesla" and self.weapon_timer >= 2.0:
            for b in enemies:
                if math.hypot(b.x - self.x, b.y - self.y) < 170:
                    b.take_damage(6, self)
                    b.frozen_timer = 1.0
                    self.tesla_targets.append((b.x, b.y))
            if self.tesla_targets:
                self.weapon_timer = 0.0

        elif self.weapon == "Boomerang" and self.weapon_timer >= 3.0:
            dx, dy = closest_enemy.x - self.x, closest_enemy.y - self.y
            length = math.hypot(dx, dy)
            if length > 0:
                projectiles.append(Projectile(
                    self.x, self.y, (dx / length) * 6, (dy / length) * 6,
                    NEON_GREEN, 7, self, is_boomerang=True, sprite_manager=self.sprites
                ))
            self.weapon_timer = 0.0

        elif self.weapon == "PushPulse" and self.weapon_timer >= 3.0:
            if dist < 180:
                self.tesla_targets.append((closest_enemy.x, closest_enemy.y))
                dx, dy = closest_enemy.x - self.x, closest_enemy.y - self.y
                l = math.hypot(dx, dy)
                if l > 0:
                    closest_enemy.vx = (dx / l) * 9
                    closest_enemy.vy = (dy / l) * 9
                    closest_enemy.take_damage(4, self)
                self.weapon_timer = 0.0

        elif self.weapon == "StickyBomb" and self.weapon_timer >= 4.5 and not self.mine_attached:
            if dist < 160:
                self.mine_attached = closest_enemy
                self.mine_timer = 0.0
                self.weapon_timer = 0.0

    def take_damage(self, amount, attacker=None):
        if self.ghost_timer > 0:
            return
        if self.shield_active:
            self.shield_active = False
            return
        self.hp -= amount
        if attacker and attacker.ability == "Vampirism" and attacker.hp > 0:
            attacker.hp = min(attacker.max_hp, attacker.hp + amount * 0.4)

    def draw(self, surface):
        if self.hp <= 0:
            return

        # 1. Ледяные и огненные следы на полу
        ice_img = self.sprites.get("ice_puddle") if self.sprites else None
        for it in self.ice_trails:
            if ice_img:
                surface.blit(ice_img, ice_img.get_rect(center=(int(it["x"]), int(it["y"]))))
            else:
                pygame.draw.circle(surface, (100, 220, 255), (int(it["x"]), int(it["y"])), 14, 2)

        fire_frames = self.sprites.fire_frames if self.sprites else []
        for ft in self.fire_trails:
            if fire_frames:
                frame = fire_frames[int(self.anim_timer * 8) % len(fire_frames)]
                surface.blit(frame, frame.get_rect(center=(int(ft["x"]), int(ft["y"]))))
            else:
                alpha = int((ft["life"] / 2.2) * 150)
                fire_surf = pygame.Surface((30, 30), pygame.SRCALPHA)
                pygame.draw.circle(fire_surf, (255, 100, 0, alpha), (15, 15), 12)
                surface.blit(fire_surf, (int(ft["x"] - 15), int(ft["y"] - 15)))

        # 2. Шлейф движения
        for i, pos in enumerate(self.trail_history):
            tx, ty = pos
            alpha = int((i / self.max_trail_len) * 60)
            trail_surf = pygame.Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(trail_surf, (*self.color, alpha), (self.radius, self.radius), self.radius - 4)
            surface.blit(trail_surf, (int(tx - self.radius), int(ty - self.radius)))

        # 3. Лучи лазера / молнии / импульса
        if self.laser_target_line:
            pygame.draw.line(surface, NEON_GREEN, (self.x, self.y), self.laser_target_line, 4)

        for target_pos in self.tesla_targets:
            if self.weapon == "Tesla":
                pygame.draw.line(surface, NEON_YELLOW, (self.x, self.y), target_pos, 2)

        if self.weapon == "PushPulse":
            pygame.draw.circle(surface, NEON_CYAN, (int(self.x), int(self.y)), 150, 2)

        # 4. Шипы вокруг шарика (Spikes — 86x86)
        if self.weapon == "Spikes":
            spikes_img = self.sprites.get("spikes_ring") if self.sprites else None
            if spikes_img:
                surface.blit(spikes_img, spikes_img.get_rect(center=(int(self.x), int(self.y))))
            else:
                pygame.draw.circle(surface, NEON_RED, (int(self.x), int(self.y)), self.radius + 6, 3)

        # 5. Сам шарик (70x70 pixel-art спрайт)
        ball_img = self.sprites.get(f"ball_{self.color_index % 4}") if self.sprites else None
        if ball_img:
            img_to_draw = ball_img.copy()
            if self.ghost_timer > 0:
                img_to_draw.set_alpha(110)
            surface.blit(img_to_draw, img_to_draw.get_rect(center=(int(self.x), int(self.y))))

            # Опциональный оверлей призрака (GhostForm — 70x70)
            if self.ghost_timer > 0:
                ghost_img = self.sprites.get("ghost_overlay")
                if ghost_img:
                    surface.blit(ghost_img, ghost_img.get_rect(center=(int(self.x), int(self.y))))
        else:
            ball_alpha = 90 if self.ghost_timer > 0 else 255
            ball_surf = pygame.Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(ball_surf, (*self.color, ball_alpha), (self.radius, self.radius), self.radius - 3)
            surface.blit(ball_surf, (int(self.x - self.radius), int(self.y - self.radius)))

        # 6. Щит поверх шарика (Shield — 84x84)
        if self.shield_active:
            shield_img = self.sprites.get("shield") if self.sprites else None
            if shield_img:
                surface.blit(shield_img, shield_img.get_rect(center=(int(self.x), int(self.y))))
            else:
                pygame.draw.circle(surface, NEON_CYAN, (int(self.x), int(self.y)), self.radius + 6, 2)

        # 7. Крутящиеся пилы (Saws — 24x24)
        if self.weapon == "Saws":
            saw_img = self.sprites.get("saw") if self.sprites else None
            for i in range(2):
                ang = self.saw_angle + (i * math.pi)
                saw_x = int(self.x + math.cos(ang) * (self.radius + 14))
                saw_y = int(self.y + math.sin(ang) * (self.radius + 14))
                if saw_img:
                    rot_saw = pygame.transform.rotate(saw_img, -math.degrees(self.saw_angle * 3))
                    surface.blit(rot_saw, rot_saw.get_rect(center=(saw_x, saw_y)))
                else:
                    pygame.draw.circle(surface, NEON_RED, (saw_x, saw_y), 8)

        # 8. Прикрепленная мина (StickyBomb — 16x16)
        if self.mine_attached and self.mine_attached.hp > 0:
            mx = int(self.mine_attached.x)
            my = int(self.mine_attached.y - self.radius - 10)
            mine_img = self.sprites.get("mine") if self.sprites else None
            if mine_img:
                surface.blit(mine_img, mine_img.get_rect(center=(mx, my)))
            else:
                pygame.draw.circle(surface, NEON_RED, (mx, my), 6)

        # 9. Цифры ХП внутри шарика
        hp_text = str(int(max(0, self.hp)))
        hp_surf = FONT_SMALL.render(hp_text, True, (255, 255, 255))
        surface.blit(hp_surf, (self.x - hp_surf.get_width() // 2, self.y - hp_surf.get_height() // 2))

        # 10. Текст задачи, название перка и полоска HP
        txt_surf = FONT_SMALL.render(self.text, True, (255, 255, 255))
        surface.blit(txt_surf, (self.x - txt_surf.get_width() // 2, self.y - self.radius - 38))
        perk_name = WEAPONS[self.weapon] if self.weapon else ABILITIES[self.ability]
        build_surf = FONT_SMALL.render(f"[{perk_name}]", True, (180, 180, 180))
        surface.blit(build_surf, (self.x - build_surf.get_width() // 2, self.y - self.radius - 22))
        hp_bar_width = 60
        hp_bar_height = 5
        hp_x = self.x - hp_bar_width // 2
        hp_y = self.y + self.radius + 8
        pygame.draw.rect(surface, (40, 40, 50), (hp_x, hp_y, hp_bar_width, hp_bar_height))
        hp_pct = max(0, self.hp / self.max_hp)
        hp_color = NEON_RED if hp_pct < 0.3 else (0, 255, 100)
        pygame.draw.rect(surface, hp_color, (hp_x, hp_y, int(hp_bar_width * hp_pct), hp_bar_height))