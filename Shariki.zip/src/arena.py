# ==========================================
# FILE: src/arena.py
# ==========================================
import pygame
from src.config import WINDOW_WIDTH, WINDOW_HEIGHT, CELL_SIZE

class Arena:
    def __init__(self, size_in_cells, sprite_manager=None):
        self.size_cells = size_in_cells
        self.pixel_size = size_in_cells * CELL_SIZE
        self.sprites = sprite_manager
        
        # Автоматически центрируем квадрат на экране
        self.x = (WINDOW_WIDTH - self.pixel_size) // 2
        self.y = (WINDOW_HEIGHT - self.pixel_size) // 2
        
        self.rect = pygame.Rect(self.x, self.y, self.pixel_size, self.pixel_size)
        self.grid_intensity = 40

        # Заранее собираем поверхность пола из тайлов (оптимизация FPS!)
        self.floor_surface = self._build_floor_surface()
        self.corners = self._build_corners()

    def _build_floor_surface(self):
        surf = pygame.Surface((self.pixel_size, self.pixel_size))
        tile = self.sprites.get("floor_tile") if self.sprites else None

        if tile:
            for row in range(self.size_cells):
                for col in range(self.size_cells):
                    surf.blit(tile, (col * CELL_SIZE, row * CELL_SIZE))
        else:
            surf.fill((15, 15, 22))
        return surf

    def _build_corners(self):
        corner_img = self.sprites.get("wall_corner") if self.sprites else None
        if not corner_img:
            return None
        # Топ-лево (0°), Топ-право (-90°), Бот-право (180°), Бот-лево (90°)
        return {
            "tl": corner_img,
            "tr": pygame.transform.rotate(corner_img, -90),
            "br": pygame.transform.rotate(corner_img, 180),
            "bl": pygame.transform.rotate(corner_img, 90),
        }
        
    def trigger_pulse(self):
        self.grid_intensity = 140

    def update(self, dt):
        if self.grid_intensity > 40:
            self.grid_intensity -= dt * 220
            if self.grid_intensity < 40:
                self.grid_intensity = 40

    def draw(self, surface):
        # 1. Отрисовка пиксельного пола
        surface.blit(self.floor_surface, (self.x, self.y))
        
        # 2. Вспышка сетки при сильных ударах
        if self.grid_intensity > 45:
            alpha = int(min(180, (self.grid_intensity - 40) * 1.8))
            flash_surf = pygame.Surface((self.pixel_size, self.pixel_size), pygame.SRCALPHA)
            pygame.draw.rect(flash_surf, (0, 255, 240, alpha), (0, 0, self.pixel_size, self.pixel_size), 4)
            surface.blit(flash_surf, (self.x, self.y))

        # 3. Внешняя неоновая рамка стен
        wall_color = (0, 180, 255)
        pygame.draw.rect(surface, (0, 60, 100), self.rect.inflate(4, 4), 1)
        pygame.draw.rect(surface, wall_color, self.rect, 3)
        
        # 4. Угловые пиксельные блоки wall_corner.png
        if self.corners:
            surface.blit(self.corners["tl"], (self.x, self.y))
            surface.blit(self.corners["tr"], (self.rect.right - CELL_SIZE, self.y))
            surface.blit(self.corners["bl"], (self.x, self.rect.bottom - CELL_SIZE))
            surface.blit(self.corners["br"], (self.rect.right - CELL_SIZE, self.rect.bottom - CELL_SIZE))
