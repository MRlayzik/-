# ==========================================
# FILE: src/assets_loader.py
# ==========================================
import os
import pygame

class SpriteManager:
    """Загружает и хранит все pixel-art спрайты игры"""
    def __init__(self):
        self.sprites = {}
        self.fire_frames = []
        self._load_all()

    def _load_image(self, rel_path, size=None):
        """Безопасная загрузка PNG с прозрачностью"""
        full_path = os.path.join("assets", "sprites", rel_path)
        if os.path.exists(full_path):
            try:
                img = pygame.image.load(full_path).convert_alpha()
                if size and img.get_size() != size:
                    img = pygame.transform.scale(img, size)
                return img
            except Exception as e:
                print(f"[SpriteManager] Ошибка загрузки {full_path}: {e}")
        else:
            print(f"[SpriteManager] Файл не найден (будет использована векторная отрисовка): {full_path}")
        return None

    def _load_all(self):
        # 1. Арена (40x40)
        self.sprites["floor_tile"] = self._load_image(os.path.join("arena", "floor_tile.png"), (40, 40))
        self.sprites["wall_corner"] = self._load_image(os.path.join("arena", "wall_corner.png"), (40, 40))

        # 2. Шарики (70x70)
        self.sprites["ball_0"] = self._load_image(os.path.join("balls", "ball_cyan.png"), (70, 70))
        self.sprites["ball_1"] = self._load_image(os.path.join("balls", "ball_magenta.png"), (70, 70))
        self.sprites["ball_2"] = self._load_image(os.path.join("balls", "ball_green.png"), (70, 70))
        self.sprites["ball_3"] = self._load_image(os.path.join("balls", "ball_yellow.png"), (70, 70))

        # 3. Оружие и снаряды
        self.sprites["saw"] = self._load_image(os.path.join("weapons", "saw.png"), (24, 24))
        self.sprites["spikes_ring"] = self._load_image(os.path.join("weapons", "spikes_ring.png"), (86, 86))
        self.sprites["bullet"] = self._load_image(os.path.join("weapons", "bullet.png"), (10, 10))
        self.sprites["rocket"] = self._load_image(os.path.join("weapons", "rocket.png"), (20, 12))
        self.sprites["boomerang"] = self._load_image(os.path.join("weapons", "boomerang.png"), (20, 20))
        self.sprites["mine"] = self._load_image(os.path.join("weapons", "mine.png"), (16, 16))

        # 4. Эффекты и способности
        self.sprites["shield"] = self._load_image(os.path.join("effects", "shield.png"), (84, 84))
        self.sprites["ice_puddle"] = self._load_image(os.path.join("effects", "ice_puddle.png"), (36, 36))
        self.sprites["ghost_overlay"] = self._load_image(os.path.join("effects", "ghost_overlay.png"), (70, 70))

        # Огонь (проверяем и одиночный файл, и кадры анимации fire_1 / fire_2)
        f1 = self._load_image(os.path.join("effects", "fire_1.png"), (28, 28))
        f2 = self._load_image(os.path.join("effects", "fire_2.png"), (28, 28))
        if f1 and f2:
            self.fire_frames = [f1, f2]
        else:
            f_single = self._load_image(os.path.join("effects", "fire_puddle.png"), (28, 28))
            if f_single:
                self.fire_frames = [f_single]

    def get(self, name):
        return self.sprites.get(name)
