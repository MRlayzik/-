import os
import pygame

# Инициализируем шрифты и графический движок
pygame.font.init()
pygame.display.init()

# ==========================================
# 📺 ДИНАМИЧЕСКИЕ НАСТРОЙКИ ЭКРАНА (ПОДСТРОЙКА ПОД МОНИТОР)
# ==========================================
# Получаем реальное разрешение монитора студента
monitor_info = pygame.display.Info()
MONITOR_WIDTH = monitor_info.current_w
MONITOR_HEIGHT = monitor_info.current_h

# Переменные окна, которые будут меняться динамически
WINDOW_WIDTH = 1200  # Стартовая ширина в оконном режиме (увеличили для пропорций)
WINDOW_HEIGHT = 800  # Стартовая высота в оконном режиме
FPS = 60


# ==========================================
# 🎨 НЕОНОВАЯ ЦВЕТОВАЯ ПАЛИТРА (КИБЕРПАНК)
# ==========================================
BG_COLOR = (10, 10, 15)          # Глубокий темно-синий/черный фон
PANEL_COLOR = (20, 20, 30)       # Цвет плашек интерфейса
TEXT_COLOR = (240, 240, 255)     # Основной белый с неоновым оттенком

NEON_CYAN = (0, 255, 240)        # Бирюзовый
NEON_MAGENTA = (255, 0, 128)     # Пурпурный
NEON_GREEN = (50, 255, 50)       # Зеленый лазер
NEON_YELLOW = (255, 230, 0)      # Желтая молния
NEON_ORANGE = (255, 100, 0)      # Огонь / Взрыв
NEON_RED = (255, 30, 30)         # Критическое ХП / Кровь
NEON_PURPLE = (150, 0, 255)      # Фантом / Телепорт

BALL_COLORS = [NEON_CYAN, NEON_MAGENTA, NEON_GREEN, NEON_YELLOW]

# ==========================================
# 📐 ПАРАМЕТРЫ АРЕНЫ И ФИЗИКИ
# ==========================================
CELL_SIZE = 40 
ARENA_SIZES = [10, 14, 18]
DEFAULT_ARENA_SIZE_INDEX = 1     # По умолчанию 14х14 клеток

# НАСТРОЙКИ ПОД ЗАПРОС: Шарики крупнее, скорость меньше
BALL_RADIUS = 35                 
BASE_BALL_SPEED = 4              

# ==========================================
# ⚔️ 10 ВИДОВ ОРУЖИЯ (АТАКА)
# ==========================================
WEAPONS = {
    "Spikes": "Шипы ⚔️",
    "Laser": "Лазер 🎯",
    "Saws": "Пилы ⚙️",
    "Shotgun": "Дробовик 💥",
    "Rocket": "Ракета 🚀",
    "FireTrail": "Огонь 🔥",
    "Tesla": "Молния ⚡",
    "StickyBomb": "Мина 💣",
    "Boomerang": "Бумеранг 🪃",
    "PushPulse": "Импульс 🌀"
}

# ==========================================
# 🛡️ 10 ВИДОВ СПОСОБНОСТЕЙ (ЗАЩИТА / ТАКТИКА)
# ==========================================
ABILITIES = {
    "Shield": "Щит 🛡️",
    "Vampirism": "Вампир 🧛",
    "Dash": "Рывок ⚡",
    "HeavyWeight": "Тяжеловес 🏋️",
    "Regen": "Реген 🧪",
    "GhostForm": "Фантом 👻",
    "IceFloor": "Лед ❄️",
    "Kamikaze": "Камикадзе 💥",
    "Magnet": "Магнит 🧲",
    "Teleport": "Телепорт 🔮"
}

# ==========================================
# 📑 ШРИФТЫ
# ==========================================
try:
    FONT_MAIN = pygame.font.SysFont("Consolas", 24)
    FONT_TITLE = pygame.font.SysFont("Consolas", 42, bold=True)
    FONT_SMALL = pygame.font.SysFont("Consolas", 16)
except:
    FONT_MAIN = pygame.font.Font(None, 28)
    FONT_TITLE = pygame.font.Font(None, 48)
    FONT_SMALL = pygame.font.Font(None, 20)
