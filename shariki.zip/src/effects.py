import pygame
import random
import math
from src.config import WINDOW_WIDTH, WINDOW_HEIGHT

class ParticleSystem:
    """Управляет всеми искрами и вспышками на экране"""
    def __init__(self):
        self.particles = []

    def create_burst(self, x, y, color, count=15):
        """Создает фонтан искр при столкновении"""
        for _ in range(count):
            angle = random.uniform(0, 2 * math.pi)
            speed = random.uniform(2, 6)
            radius = random.uniform(2, 5)
            lifetime = random.uniform(0.3, 0.8) # Время жизни частицы в секундах
            
            self.particles.append({
                "x": x,
                "y": y,
                "vx": math.cos(angle) * speed,
                "vy": math.sin(angle) * speed,
                "radius": radius,
                "color": color,
                "lifetime": lifetime,
                "max_lifetime": lifetime
            })

    def update(self, dt):
        """Обновляет физику частиц и удаляет угасшие"""
        for p in self.particles[:]:
            p["x"] += p["vx"]
            p["y"] += p["vy"]
            p["lifetime"] -= dt
            
            # Слегка замедляем частицы со временем (сопротивление воздуха)
            p["vx"] *= 0.95
            p["vy"] *= 0.95
            
            if p["lifetime"] <= 0:
                self.particles.remove(p)

    def draw(self, surface):
        """Рисует частицы с эффектом неонового затухания"""
        for p in self.particles:
            # Рассчитываем прозрачность на основе оставшегося времени жизни
            alpha = int((p["lifetime"] / p["max_lifetime"]) * 255)
            if alpha <= 0: continue
            
            # Создаем временную поверхность для рисования полупрозрачной частицы
            size = int(p["radius"] * 4)
            if size < 1: size = 1
            surf = pygame.Surface((size, size), pygame.SRCALPHA)
            
            # Рисуем светящееся ядро и мягкую ауру вокруг
            r, g, b = p["color"]
            pygame.draw.circle(surf, (r, g, b, alpha), (size // 2, size // 2), p["radius"])
            pygame.draw.circle(surf, (r, g, b, alpha // 3), (size // 2, size // 2), p["radius"] * 1.8)
            
            surface.blit(surf, (int(p["x"] - size // 2), int(p["y"] - size // 2)))


class ScreenShake:
    """Эффект сочного сотрясения экрана при сильных ударах"""
    def __init__(self):
        self.duration = 0
        self.intensity = 0
        self.offset_x = 0
        self.offset_y = 0

    def trigger(self, duration=0.2, intensity=8):
        """Включает тряску камеры"""
        self.duration = duration
        self.intensity = intensity

    def update(self, dt):
        """Рассчитывает случайное смещение для кадра"""
        if self.duration > 0:
            self.duration -= dt
            # Генерируем случайный сдвиг в пределах текущей интенсивности
            self.offset_x = random.randint(-self.intensity, self.intensity)
            self.offset_y = random.randint(-self.intensity, self.intensity)
            
            # Постепенно затухает тряска
            if self.duration <= 0:
                self.offset_x = 0
                self.offset_y = 0
        else:
            self.offset_x = 0
            self.offset_y = 0

    def apply(self, surface):
        """
        Применяет сдвиг ко всему экрану.
        Для этого мы рендерим всю игру на виртуальный холст,
        а при выводе на основной экран смещаем его на offset_x/y.
        """
        pass # Реализуем эту склейку на этапе отрисовки стейта арены
