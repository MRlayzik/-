# ==========================================
# FILE: src/states.py
# ==========================================
import pygame
import random
import math
from src.config import (
    WINDOW_WIDTH, WINDOW_HEIGHT, PANEL_COLOR, TEXT_COLOR,
    FONT_TITLE, FONT_MAIN, FONT_SMALL, BALL_COLORS,
    NEON_CYAN, NEON_MAGENTA, NEON_GREEN, NEON_ORANGE, ARENA_SIZES
)
from src.arena import Arena
from src.entities import Ball
from src.effects import ParticleSystem, ScreenShake

class StateManager:
    def __init__(self):
        self.states = {
            "MENU": MenuState(),
            "BATTLE": BattleState()
        }
        self.current_state = self.states["MENU"]
        self.should_quit = False
        
        # 📐 ОПРЕДЕЛЯЕМ ЗОНЫ КНОПОК УПРАВЛЕНИЯ ОКНОМ (справа вверху)
        self.btn_minimize = pygame.Rect(WINDOW_WIDTH - 120, 15, 30, 30)
        self.btn_fullscreen = pygame.Rect(WINDOW_WIDTH - 80, 15, 30, 30)
        self.btn_close = pygame.Rect(WINDOW_WIDTH - 40, 15, 30, 30)

    def change_state(self, state_name, data=None):
        if state_name in self.states:
            self.current_state = self.states[state_name]
            self.current_state.enter(data)

    def handle_events(self, events):
        # Сначала проверяем клики по системным кнопкам верхнего угла
        for event in events:
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1: # Левый клик мыши
                    x, y = event.pos
                    
                    # ❌ Кнопка Закрыть
                    if self.btn_close.collidepoint(x, y):
                        self.should_quit = True
                        return
                    
                    # 🗖 Кнопка Развернуть (Во весь экран)
                    if self.btn_fullscreen.collidepoint(x, y):
                        # Отправляем кастомное событие в main.py для переключения режима
                        pygame.event.post(pygame.event.Event(pygame.USEREVENT + 1))
                        return
                    
                    #  Кнопка Свернуть
                    if self.btn_minimize.collidepoint(x, y):
                        pygame.display.iconify()
                        return
                        
        # Если клик пришелся не по системным кнопкам, передаем управление текущему экрану
        self.current_state.handle_events(events, self)

    def update(self, dt):
        self.current_state.update(dt)

    def draw(self, screen):
        # 1. Рисуем содержимое текущего экрана
        self.current_state.draw(screen)
        
        # 2. Поверх всего рисуем наши неоновые системные кнопки окна
        mx, my = pygame.mouse.get_pos()
        
        # Цвета подсветки при наведении курсора (Hover)
        color_min = NEON_CYAN if self.btn_minimize.collidepoint(mx, my) else (60, 60, 80)
        color_full = NEON_GREEN if self.btn_fullscreen.collidepoint(mx, my) else (60, 60, 80)
        color_close = NEON_MAGENTA if self.btn_close.collidepoint(mx, my) else (60, 60, 80)
        
        # Рисуем рамки кнопок
        pygame.draw.rect(screen, PANEL_COLOR, self.btn_minimize, 0, 4)
        pygame.draw.rect(screen, color_min, self.btn_minimize, 1, 4)
        
        pygame.draw.rect(screen, PANEL_COLOR, self.btn_fullscreen, 0, 4)
        pygame.draw.rect(screen, color_full, self.btn_fullscreen, 1, 4)
        
        pygame.draw.rect(screen, PANEL_COLOR, self.btn_close, 0, 4)
        pygame.draw.rect(screen, color_close, self.btn_close, 1, 4)
        
        # Рисуем значки внутри рамок (Линии и Символы)
        # Свернуть (_)
        pygame.draw.line(screen, TEXT_COLOR, (self.btn_minimize.x + 8, self.btn_minimize.y + 20), (self.btn_minimize.x + 22, self.btn_minimize.y + 20), 2)
        
        # Развернуть (Квадратик)
        pygame.draw.rect(screen, TEXT_COLOR, (self.btn_fullscreen.x + 8, self.btn_fullscreen.y + 8, 14, 14), 2)
        
        # Закрыть (Крестик)
        pygame.draw.line(screen, TEXT_COLOR, (self.btn_close.x + 9, self.btn_close.y + 9), (self.btn_close.x + 21, self.btn_close.y + 21), 2)
        pygame.draw.line(screen, TEXT_COLOR, (self.btn_close.x + 21, self.btn_close.y + 9), (self.btn_close.x + 9, self.btn_close.y + 21), 2)



class MenuState:
    """Интерактивное меню киберпанк-интерфейса"""
    def __init__(self):
        # 4 текстовых поля для ввода задач студентом
        self.inputs = ["Погулять", "Делать уроки", "Смотреть YouTube", "Писать код"]
        self.active_input_idx = 0
        
        # Настройка размеров арены (10, 14, 18 клеток)
        self.size_indices = ARENA_SIZES
        self.current_size_idx = 1 # По умолчанию 14х14
        
        # Интерактивные кнопки (зоны клика)
        self.btn_start_rect = pygame.Rect(WINDOW_WIDTH // 2 - 150, WINDOW_HEIGHT - 120, 300, 60)
        self.btn_size_rect = pygame.Rect(WINDOW_WIDTH // 2 - 100, WINDOW_HEIGHT - 220, 200, 40)
        
        # Эффект неонового мерцания заголовка
        self.glow_timer = 0

    def enter(self, data):
        pass

    def handle_events(self, events, manager):
        for event in events:
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                # Клик по кнопке СТАРТ
                if self.btn_start_rect.collidepoint(x, y):
                    self.start_battle(manager)
                # Клик по кнопке переключения размера арены
                if self.btn_size_rect.collidepoint(x, y):
                    self.current_size_idx = (self.current_size_idx + 1) % len(self.size_indices)
                
                # Клик по текстовым полям
                for i in range(4):
                    field_rect = pygame.Rect(WINDOW_WIDTH // 2 - 200, 250 + i * 70, 400, 45)
                    if field_rect.collidepoint(x, y):
                        self.active_input_idx = i

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    self.start_battle(manager)
                elif event.key == pygame.K_TAB:
                    self.active_input_idx = (self.active_input_idx + 1) % 4
                elif event.key == pygame.K_BACKSPACE:
                    self.inputs[self.active_input_idx] = self.inputs[self.active_input_idx][:-1]
                else:
                    # Добавляем символ, если строка не слишком длинная
                    if len(self.inputs[self.active_input_idx]) < 20 and event.unicode.isprintable():
                        self.inputs[self.active_input_idx] += event.unicode

    def start_battle(self, manager):
        valid_tasks = [t.strip() for t in self.inputs if t.strip() != ""]
        if len(valid_tasks) >= 2:
            battle_data = {
                "tasks": valid_tasks,
                "arena_size": self.size_indices[self.current_size_idx]
            }
            manager.change_state("BATTLE", battle_data)

    def update(self, dt):
        self.glow_timer += dt * 5

    def draw(self, screen):
        # 1. Заголовок с неоновой пульсацией
        glow = int(180 + 75 * math.sin(self.glow_timer))
        title_color = (glow, 0, glow)
        title_txt = FONT_TITLE.render("BALL DECISION ARENA", True, title_color)
        screen.blit(title_txt, (WINDOW_WIDTH // 2 - title_txt.get_width() // 2, 60))
        
        subtitle_txt = FONT_SMALL.render("Введи от 2 до 4 задач. Какой шарик выживет — то решение и будет принято!", True, NEON_CYAN)
        screen.blit(subtitle_txt, (WINDOW_WIDTH // 2 - subtitle_txt.get_width() // 2, 130))

        # 2. Отрисовка полей ввода задач
        for i in range(4):
            is_active = (i == self.active_input_idx)
            field_rect = pygame.Rect(WINDOW_WIDTH // 2 - 200, 250 + i * 70, 400, 45)
            
            pygame.draw.rect(screen, PANEL_COLOR, field_rect, 0, 6)
            border_color = NEON_CYAN if is_active else (60, 60, 80)
            pygame.draw.rect(screen, border_color, field_rect, 2, 6)
            
            val_txt = FONT_MAIN.render(self.inputs[i] + ("|" if is_active and int(self.glow_timer) % 2 == 0 else ""), True, TEXT_COLOR)
            screen.blit(val_txt, (field_rect.x + 15, field_rect.y + 10))
            
            num_txt = FONT_MAIN.render(f"#{i+1}", True, BALL_COLORS[i])
            screen.blit(num_txt, (field_rect.x - 45, field_rect.y + 10))

        # 3. Кнопка выбора размера арены
        pygame.draw.rect(screen, PANEL_COLOR, self.btn_size_rect, 0, 4)
        pygame.draw.rect(screen, NEON_GREEN, self.btn_size_rect, 1, 4)
        size_txt = FONT_MAIN.render(f"Размер: {self.size_indices[self.current_size_idx]}x{self.size_indices[self.current_size_idx]}", True, TEXT_COLOR)
        screen.blit(size_txt, (self.btn_size_rect.x + (self.btn_size_rect.width - size_txt.get_width())//2, self.btn_size_rect.y + 8))

        # 4. Большая неоновая кнопка СТАРТ
        pygame.draw.rect(screen, (10, 40, 20), self.btn_start_rect, 0, 8)
        pygame.draw.rect(screen, NEON_GREEN, self.btn_start_rect, 3, 8)
        start_txt = FONT_TITLE.render("НАЧАТЬ БИТВУ", True, NEON_GREEN)
        screen.blit(start_txt, (self.btn_start_rect.x + (self.btn_start_rect.width - start_txt.get_width())//2, self.btn_start_rect.y + 8))


class BattleState:
    """Экран самой боевой арены с частицами, тряской и расчетом победителя"""
    def __init__(self):
        self.arena = None
        self.balls = []
        self.projectiles = []
        self.particles = ParticleSystem()
        self.shake = ScreenShake()
        self.game_over = False
        self.winner_text = ""
        self.slow_mo = False
        self.slow_mo_timer = 0.0

    def enter(self, data):
        self.balls.clear()
        self.projectiles.clear()
        self.game_over = False
        self.slow_mo = False
        self.winner_text = ""
        
        self.arena = Arena(data["arena_size"])
        
        tasks = data["tasks"]
        for i, task in enumerate(tasks):
            bx = random.randint(self.arena.rect.left + 50, self.arena.rect.right - 50)
            by = random.randint(self.arena.rect.top + 50, self.arena.rect.bottom - 50)
            
            new_ball = Ball(bx, by, task, BALL_COLORS[i])
            self.balls.append(new_ball)

    def handle_events(self, events, manager):
        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    manager.change_state("MENU")
                if event.key == pygame.K_RETURN and self.game_over:
                    manager.change_state("MENU")

    def update(self, dt):
        if self.slow_mo:
            dt *= 0.25

        self.shake.update(dt)
        self.arena.update(dt)
        self.particles.update(dt)

        active_balls = [b for b in self.balls if b.hp > 0]

        if len(active_balls) <= 1 and not self.game_over:
            self.game_over = True
            if len(active_balls) == 1:
                self.winner_text = f"Выбор сделан: {active_balls[0].text}!"
            else:
                self.winner_text = "Ничья! Все шарики уничтожены!"

        if len(active_balls) == 2 and not self.slow_mo:
            if any(b.hp < 25 for b in active_balls):
                self.slow_mo = True

        for ball in active_balls:
            ball.update_physics(dt, self.arena.rect)
            ball.update_logic(dt, self.balls, self.projectiles)

        for i in range(len(active_balls)):
            for j in range(i + 1, len(active_balls)):
                b1 = active_balls[i]
                b2 = active_balls[j]
                
                dx = b2.x - b1.x
                dy = b2.y - b1.y
                dist = math.hypot(dx, dy)
                
                if dist < b1.radius + b2.radius:
                    b1.vx, b2.vx = b2.vx, b1.vx
                    b1.vy, b2.vy = b2.vy, b1.vy
                    
                    overlap = (b1.radius + b2.radius) - dist
                    if dist == 0: dist = 1
                    b1.x -= (dx / dist) * overlap * 0.5
                    b1.y -= (dy / dist) * overlap * 0.5
                    b2.x += (dx / dist) * overlap * 0.5
                    b2.y += (dy / dist) * overlap * 0.5

                    b1.take_damage(3, b2)
                    b2.take_damage(3, b1)
                    
                    mid_x = b1.x + (dx / dist) * b1.radius
                    mid_y = b1.y + (dy / dist) * b1.radius
                    self.particles.create_burst(mid_x, mid_y, NEON_CYAN, count=12)
                    
                    self.arena.trigger_pulse()
                    self.shake.trigger(duration=0.15, intensity=6)

        for p in self.projectiles[:]:
            target = None
            enemies = [b for b in active_balls if b != p.owner]
            if enemies:
                target = enemies[0]
            
            p.update(dt, target)
            
            for ball in active_balls:
                if ball != p.owner:
                    if math.hypot(ball.x - p.x, ball.y - p.y) < ball.radius + p.radius:
                        ball.take_damage(p.damage, p.owner)
                        self.particles.create_burst(p.x, p.y, p.color, count=10)
                        self.shake.trigger(duration=0.2, intensity=8)
                        p.alive = False
                        break
            
            if not self.arena.rect.collidepoint(p.x, p.y):
                p.alive = False
                
            if not p.alive:
                self.projectiles.remove(p)

    def draw(self, screen):
        canvas = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
        canvas.fill((10, 10, 15))

        self.arena.draw(canvas)
        
        for p in self.projectiles:
            p.draw(canvas)
            
        for ball in self.balls:
            ball.draw(canvas)
            
        self.particles.draw(canvas)

        screen.blit(canvas, (self.shake.offset_x, self.shake.offset_y))

        back_txt = FONT_SMALL.render("Нажми ESC для возврата в меню", True, (120, 120, 150))
        screen.blit(back_txt, (20, 20))
        
        if self.slow_mo and not self.game_over:
            slow_txt = FONT_SMALL.render("ФИНАЛЬНЫЙ ОТСЧЕТ (SLOW-MO)", True, NEON_MAGENTA)
            screen.blit(slow_txt, (WINDOW_WIDTH // 2 - slow_txt.get_width() // 2, 20))

        if self.game_over:
            overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
            overlay.fill((5, 5, 10, 200))
            screen.blit(overlay, (0, 0))
            
            win_panel = pygame.Rect(WINDOW_WIDTH // 2 - 300, WINDOW_HEIGHT // 2 - 100, 600, 200)
            pygame.draw.rect(screen, PANEL_COLOR, win_panel, 0, 12)
            pygame.draw.rect(screen, NEON_CYAN, win_panel, 2, 12)
            
            res_txt = FONT_TITLE.render(self.winner_text, True, NEON_GREEN)
            screen.blit(res_txt, (WINDOW_WIDTH // 2 - res_txt.get_width() // 2, WINDOW_HEIGHT // 2 - 40))
            
            hint_txt = FONT_MAIN.render("Нажми ENTER для нового выбора", True, TEXT_COLOR)
            screen.blit(hint_txt, (WINDOW_WIDTH // 2 - hint_txt.get_width() // 2, WINDOW_HEIGHT // 2 + 30))
