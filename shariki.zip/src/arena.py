import pygame
from src.config import WINDOW_WIDTH, WINDOW_HEIGHT, CELL_SIZE, BG_COLOR, PANEL_COLOR

class Arena:
    def __init__(self, size_in_cells):
        """
        size_in_cells: размер стороны квадрата (например, 10, 14, 18 клеток)
        """
        self.size_cells = size_in_cells
        self.pixel_size = size_in_cells * CELL_SIZE
        
        # Автоматически центрируем квадрат на экране
        self.x = (WINDOW_WIDTH - self.pixel_size) // 2
        self.y = (WINDOW_HEIGHT - self.pixel_size) // 2
        
        # Основной прямоугольник арены для просчета столкновений
        self.rect = pygame.Rect(self.x, self.y, self.pixel_size, self.pixel_size)
        
        # Эффект пульсации сетки (для сочности)
        self.pulse_timer = 0.0
        self.grid_intensity = 40  # Базовая яркость сетки
        
    def trigger_pulse(self):
        """Вызывается при сильном ударе, чтобы сетка на мгновение вспыхнула"""
        self.grid_intensity = 120

    def update(self, dt):
        # Плавно возвращаем сетку к обычному тусклому состоянию
        if self.grid_intensity > 40:
            self.grid_intensity -= dt * 200
            if self.grid_intensity < 40:
                self.grid_intensity = 40

    def draw(self, surface):
        """Отрисовка неоновой сетки и внешних стен"""
        # 1. Заливаем внутреннюю часть арены чуть более глубоким цветом
        pygame.draw.rect(surface, (15, 15, 22), self.rect)
        
        # 2. Рисуем внутреннюю сетку киберпанк-арены
        color_val = int(max(15, min(self.grid_intensity, 255)))
        grid_color = (color_val // 2, color_val, color_val) # Бирюзовый оттенок
        
        # Вертикальные линии
        for col in range(1, self.size_cells):
            lx = self.x + col * CELL_SIZE
            pygame.draw.line(surface, grid_color, (lx, self.y), (lx, self.y + self.pixel_size), 1)
            
        # Горизонтальные линии
        for row in range(1, self.size_cells):
            ly = self.y + row * CELL_SIZE
            pygame.draw.line(surface, grid_color, (self.x, ly), (self.x + self.pixel_size, ly), 1)
            
        # 3. Рисуем внешнюю толстую рамку (стены) с эффектом легкого неонового свечения
        wall_color = (0, 180, 255)
        # Внешнее размытие стены
        pygame.draw.rect(surface, (0, 60, 100), self.rect.inflate(4, 4), 1)
        # Основная стена
        pygame.draw.rect(surface, wall_color, self.rect, 3)
        
        # 4. Декоративные углы арены (чтобы выглядело технологично)
        corner_len = 20
        corners = [
            ((self.x, self.y), (self.x + corner_len, self.y), (self.x, self.y + corner_len)), # Топ-Лево
            ((self.rect.right, self.y), (self.rect.right - corner_len, self.y), (self.rect.right, self.y + corner_len)), # Топ-Право
            ((self.x, self.rect.bottom), (self.x + corner_len, self.rect.bottom), (self.x, self.rect.bottom - corner_len)), # Бот-Лево
            ((self.rect.right, self.rect.bottom), (self.rect.right - corner_len, self.rect.bottom), (self.rect.right, self.rect.bottom - corner_len)) # Бот-Право
        ]
        for c in corners:
            pygame.draw.line(surface, (255, 0, 128), c[0], c[1], 4)
            pygame.draw.line(surface, (255, 0, 128), c[0], c[2], 4)
