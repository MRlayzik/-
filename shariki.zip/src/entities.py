import pygame
import random
import math
from src.config import (
    BALL_RADIUS, BASE_BALL_SPEED, WEAPONS, ABILITIES, 
    FONT_SMALL, NEON_RED, NEON_CYAN, NEON_PURPLE, NEON_ORANGE, NEON_YELLOW, NEON_GREEN
)

class Projectile:
    """Класс для снарядов (пули дробовика, ракеты, бумеранги)"""
    def __init__(self, x, y, vx, vy, color, damage, owner, is_rocket=False, is_boomerang=False):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.radius = 4 if not is_rocket else 7
        if is_boomerang: self.radius = 8
        self.color = color
        self.damage = damage
        self.owner = owner  
        self.is_rocket = is_rocket
        self.is_boomerang = is_boomerang
        self.alive = True
        
        # Для бумеранга
        self.life_timer = 0.0
        self.returning = False

    def update(self, dt, target_ball=None):
        if self.is_rocket and target_ball:
            dx = target_ball.x - self.x
            dy = target_ball.y - self.y
            dist = math.hypot(dx, dy)
            if dist > 0:
                target_vx = (dx / dist) * 5
                target_vy = (dy / dist) * 5
                self.vx += (target_vx - self.vx) * 0.05
                self.vy += (target_vy - self.vy) * 0.05

        elif self.is_boomerang:
            self.life_timer += dt
            if self.life_timer > 1.2 and not self.returning:
                self.returning = True
            
            if self.returning:
                # Летит обратно к хозяину
                dx = self.owner.x - self.x
                dy = self.owner.y - self.y
                dist = math.hypot(dx, dy)
                if dist > 10:
                    self.vx = (dx / dist) * 8
                    self.vy = (dy / dist) * 8
                else:
                    self.alive = False # Вернулся в руки

        self.x += self.vx
        self.y += self.vy

    def draw(self, surface):
        if self.is_boomerang:
            # Рисуем крутящийся крестик/бумеранг
            pygame.draw.circle(surface, self.color, (int(self.x), int(self.y)), self.radius, 2)
            pygame.draw.line(surface, self.color, (self.x - 6, self.y), (self.x + 6, self.y), 2)
        else:
            pygame.draw.circle(surface, self.color, (int(self.x), int(self.y)), self.radius)
            pygame.draw.circle(surface, (255, 255, 255), (int(self.x), int(self.y)), self.radius // 2)


class Ball:
    def __init__(self, x, y, text, color):
        self.x = x
        self.y = y
        self.radius = BALL_RADIUS
        self.text = text
        self.color = color
        self.hp = 100
        self.max_hp = 100
        
        # Разделение классов
        self.archetype = random.choice(["WEAPON", "ABILITY"])
        if self.archetype == "WEAPON":
            self.weapon = random.choice(list(WEAPONS.keys()))
            self.ability = None
        else:
            self.weapon = None
            self.ability = random.choice(list(ABILITIES.keys()))
        
        # Физика движения
        angle = random.uniform(0, 2 * math.pi)
        self.vx = math.cos(angle) * BASE_BALL_SPEED
        self.vy = math.sin(angle) * BASE_BALL_SPEED
        
        self.weapon_timer = random.uniform(0, 1.0)
        self.ability_timer = random.uniform(0, 1.0)
        
        # Эффекты
        self.shield_active = (self.ability == "Shield")
        self.ghost_timer = 0.0
        self.frozen_timer = 0.0
        
        # Для визуализации оружия дальнего/ближнего боя
        self.saw_angle = 0.0
        self.laser_target_line = None
        self.tesla_targets = []
        self.fire_trails = [] # Список точек огненного следа
        self.mine_attached = None # Ссылка на того, к кому прикрепили мину
        self.mine_timer = 0.0

        self.trail_history = []
        self.max_trail_len = 8

    def update_physics(self, dt, arena_rect):
        current_speed_modifier = 0.5 if self.frozen_timer > 0 else 1.0
        if self.frozen_timer > 0: self.frozen_timer -= dt
        if self.ability == "HeavyWeight": current_speed_modifier *= 0.8

        self.x += self.vx * current_speed_modifier
        self.y += self.vy * current_speed_modifier

        self.trail_history.append((self.x, self.y))
        if len(self.trail_history) > self.max_trail_len: self.trail_history.pop(0)

        # Обработка Огненного следа (FireTrail)
        if self.weapon == "FireTrail":
            self.ability_timer += dt
            if self.ability_timer > 0.15: # Оставляем пламя каждые 0.15 сек
                self.fire_trails.append({"x": self.x, "y": self.y, "life": 2.0})
                self.ability_timer = 0
        
        # Обновляем время жизни огня
        for ft in self.fire_trails[:]:
            ft["life"] -= dt
            if ft["life"] <= 0: self.fire_trails.remove(ft)

        # Отскоки от стен арены
        hit_wall = False
        if self.x - self.radius < arena_rect.left:
            self.x = arena_rect.left + self.radius; self.vx *= -1; hit_wall = True
        elif self.x + self.radius > arena_rect.right:
            self.x = arena_rect.right - self.radius; self.vx *= -1; hit_wall = True

        if self.y - self.radius < arena_rect.top:
            self.y = arena_rect.top + self.radius; self.vy *= -1; hit_wall = True
        elif self.y + self.radius > arena_rect.bottom:
            self.y = arena_rect.bottom - self.radius; self.vy *= -1; hit_wall = True

        # ЭФФЕКТ ДРОБОВИКА ПРИ УДАРЕ ОБ СТЕНУ
        if hit_wall and self.weapon == "Shotgun" and self.weapon_timer > 1.0:
            self.weapon_timer = -0.5 # триггер дробовика

    def update_logic(self, dt, all_balls, projectiles):
        if self.hp <= 0:
            # ЭФФЕКТ КАМИКАДЗЕ ПРИ СМЕРТИ
            if self.ability == "Kamikaze":
                self.ability = None # Активируется один раз
                for b in all_balls:
                    if b != self and b.hp > 0:
                        dist = math.hypot(b.x - self.x, b.y - self.y)
                        if dist < 250: # Радиус ядерного взрыва
                            b.take_damage(35, self)
            return

        # Вращение пил
        if self.weapon == "Saws":
            self.saw_angle += dt * 5

        # Пассивные перки
        if self.ability == "Regen" and self.hp < self.max_hp:
            self.hp = min(self.max_hp, self.hp + dt * 2.0)
        if self.ability == "GhostForm" and self.hp < 30 and self.ghost_timer <= 0:
            self.ghost_timer = 3.0
        if self.ghost_timer > 0: self.ghost_timer -= dt

        if self.ability == "Shield" and not self.shield_active:
            self.ability_timer += dt
            if self.ability_timer >= 7.0:
                self.shield_active = True
                self.ability_timer = 0

        # Считывание урона от Огненных следов врагов
        for b in all_balls:
            if b != self and b.hp > 0 and b.weapon == "FireTrail":
                for ft in b.fire_trails:
                    if math.hypot(self.x - ft["x"], self.y - ft["y"]) < self.radius + 10:
                        self.take_damage(dt * 15, b) # Периодический урон огня

        # Нанесение урона Пилами (Saws) в ближнем бою
        if self.weapon == "Saws":
            for b in all_balls:
                if b != self and b.hp > 0:
                    if math.hypot(b.x - self.x, b.y - self.y) < self.radius + 25:
                        b.take_damage(dt * 10, self) # Пилим врага каждую секунду

        # Активация таймера Мины
        if self.mine_attached:
            self.mine_timer += dt
            if self.mine_timer >= 2.0:
                if self.mine_attached.hp > 0:
                    self.mine_attached.take_damage(25, self)
                    # Урон по области вокруг заминированного
                    for b in all_balls:
                        if b != self.mine_attached and b.hp > 0:
                            if math.hypot(b.x - self.mine_attached.x, b.y - self.mine_attached.y) < 120:
                                b.take_damage(15, self)
                self.mine_attached = None
                self.mine_timer = 0.0

        # Атака оружием
        if self.weapon:
            self.weapon_timer += dt
            self.trigger_weapon(dt, projectiles, all_balls)

    def trigger_weapon(self, dt, projectiles, all_balls):
        enemies = [b for b in all_balls if b != self and b.hp > 0]
        if not enemies: return
        closest_enemy = min(enemies, key=lambda b: math.hypot(b.x - self.x, b.y - self.y))
        dist = math.hypot(closest_enemy.x - self.x, closest_enemy.y - self.y)

        # Очищаем старый визуал
        self.laser_target_line = None
        self.tesla_targets.clear()

        # Триггер Дробовика
        if self.weapon == "Shotgun" and self.weapon_timer < -0.1:
            for _ in range(6):
                ang = random.uniform(0, 2 * math.pi)
                projectiles.append(Projectile(self.x, self.y, math.cos(ang)*5, math.sin(ang)*5, NEON_ORANGE, 4, self))
            self.weapon_timer = 0.0

        # ЛАЗЕР
        elif self.weapon == "Laser" and self.weapon_timer >= 2.5:
            if dist < 350:
                closest_enemy.take_damage(10, self)
                self.laser_target_line = (closest_enemy.x, closest_enemy.y)
                self.weapon_timer = 0.0

        # РАКЕТА
        elif self.weapon == "Rocket" and self.weapon_timer >= 3.5:
            dx, dy = closest_enemy.x - self.x, closest_enemy.y - self.y
            length = math.hypot(dx, dy)
            if length > 0:
                projectiles.append(Projectile(self.x, self.y, (dx/length)*3, (dy/length)*3, NEON_CYAN, 8, self, is_rocket=True))
                self.weapon_timer = 0.0

        # МОЛНИЯ
        elif self.weapon == "Tesla" and self.weapon_timer >= 2.0:
            for b in enemies:
                if math.hypot(b.x - self.x, b.y - self.y) < 160:
                    b.take_damage(6, self)
                    b.frozen_timer = 1.0 
                    self.tesla_targets.append((b.x, b.y))
            if self.tesla_targets:
                self.weapon_timer = 0.0

        # БУМЕРАНГ
        elif self.weapon == "Boomerang" and self.weapon_timer >= 3.0:
            dx, dy = closest_enemy.x - self.x, closest_enemy.y - self.y
            length = math.hypot(dx, dy)
            if length > 0:
                projectiles.append(Projectile(self.x, self.y, (dx/length)*6, (dy/length)*6, NEON_GREEN, 7, self, is_boomerang=True))
                self.weapon_timer = 0.0

        # ИМПУЛЬС
        elif self.weapon == "PushPulse" and self.weapon_timer >= 3.0:
            if dist < 180:
                self.tesla_targets.append((closest_enemy.x, closest_enemy.y))
                dx, dy = closest_enemy.x - self.x, closest_enemy.y - self.y
                l = math.hypot(dx, dy)
                if l > 0:
                    closest_enemy.vx = (dx / l) * 8
                    closest_enemy.vy = (dy / l) * 8
                    closest_enemy.take_damage(3, self)
                self.weapon_timer = 0.0

    def take_damage(self, amount, attacker=None):
        if self.ghost_timer > 0: return 
        if self.shield_active:
            self.shield_active = False 
            return

        self.hp -= amount
        
        if attacker and attacker.ability == "Vampirism" and attacker.hp > 0:
            attacker.hp = min(attacker.max_hp, attacker.hp + amount * 0.4)

    def draw(self, surface):
        if self.hp <= 0: return

        # Отрисовка огненных луж на полу
        for ft in self.fire_trails:
            alpha = int((ft["life"] / 2.0) * 150)
            fire_surf = pygame.Surface((30, 30), pygame.SRCALPHA)
            pygame.draw.circle(fire_surf, (255, 100, 0, alpha), (15, 15), 12)
            surface.blit(fire_surf, (int(ft["x"] - 15), int(ft["y"] - 15)))

        # 1. Рисуем шлейф
        for i, pos in enumerate(self.trail_history):
            tx, ty = pos # Разделяем кортеж на отдельные координаты X и Y
            alpha = int((i / self.max_trail_len) * 80)
            trail_surf = pygame.Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(trail_surf, (*self.color, alpha), (self.radius, self.radius), self.radius)
            # Теперь вычитаем радиус из конкретных чисел tx и ty
            surface.blit(trail_surf, (int(tx - self.radius), int(ty - self.radius)))


        # ОТРИСОВКА МОЛНИЙ И ЛАЗЕРОВ В МОМЕНТ ВЫСТРЕЛА
        if self.laser_target_line:
            pygame.draw.line(surface, NEON_GREEN, (self.x, self.y), self.laser_target_line, 4)
        for target_pos in self.tesla_targets:
            if self.weapon == "Tesla":
                pygame.draw.line(surface, NEON_YELLOW, (self.x, self.y), target_pos, 2)
            elif self.weapon == "PushPulse":
                pygame.draw.circle(surface, NEON_CYAN, (int(self.x), int(self.y)), 150, 2)

        # Рисуем сам шарик
        ball_alpha = 90 if self.ghost_timer > 0 else 255
        ball_surf = pygame.Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
        pygame.draw.circle(ball_surf, (*self.color, ball_alpha // 4), (self.radius, self.radius), self.radius)
        pygame.draw.circle(ball_surf, (*self.color, ball_alpha), (self.radius, self.radius), self.radius - 3)
        surface.blit(ball_surf, (int(self.x - self.radius), int(self.y - self.radius)))

        # ОТРИСОВКА КРУТЯЩИХСЯ ПИЛ
        if self.weapon == "Saws":
            for i in range(2):
                ang = self.saw_angle + (i * math.pi)
                saw_x = int(self.x + math.cos(ang) * (self.radius + 15))
                saw_y = int(self.y + math.sin(ang) * (self.radius + 15))
                pygame.draw.circle(surface, NEON_RED, (saw_x, saw_y), 8)
                pygame.draw.circle(surface, (255, 255, 255), (saw_x, saw_y), 3)

        # ОТРИСОВКА ТАЙМЕРА МИНЫ НА ВРАГЕ
        if self.mine_attached:
            pygame.draw.circle(surface, NEON_RED, (int(self.mine_attached.x), int(self.mine_attached.y) - self.radius - 10), 6)

        # Цифры ХП
        hp_text = str(int(max(0, self.hp)))
        hp_surf = FONT_SMALL.render(hp_text, True, (255, 255, 255))
        surface.blit(hp_surf, (self.x - hp_surf.get_width() // 2, self.y - hp_surf.get_height() // 2))

        if self.shield_active:
            pygame.draw.circle(surface, NEON_CYAN, (int(self.x), int(self.y)), self.radius + 6, 2)

        # Название задачи
        txt_surf = FONT_SMALL.render(self.text, True, (255, 255, 255))
        surface.blit(txt_surf, (self.x - txt_surf.get_width() // 2, self.y - self.radius - 35))
        
        perk_name = WEAPONS[self.weapon] if self.weapon else ABILITIES[self.ability]
        build_surf = FONT_SMALL.render(f"[{perk_name}]", True, (180, 180, 180))
        surface.blit(build_surf, (self.x - build_surf.get_width() // 2, self.y - self.radius - 20))

        # Полоска здоровья
        hp_bar_width = 60
        hp_bar_height = 5
        hp_x = self.x - hp_bar_width // 2
        hp_y = self.y + self.radius + 8
        
        pygame.draw.rect(surface, (40, 40, 50), (hp_x, hp_y, hp_bar_width, hp_bar_height))
        hp_pct = max(0, self.hp / self.max_hp)
        hp_color = NEON_RED if hp_pct < 0.3 else (0, 255, 100)
        pygame.draw.rect(surface, hp_color, (hp_x, hp_y, int(hp_bar_width * hp_pct), hp_bar_height))
