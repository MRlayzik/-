import pygame
import sys
from src.config import WINDOW_WIDTH, WINDOW_HEIGHT, FPS, BG_COLOR
from src.states import StateManager

def main():
    pygame.init()
    pygame.mixer.init()
    
    is_fullscreen = False
    
    # 🎯 РЕШЕНИЕ: Добавляем флаг pygame.SCALED к базовому оконному режиму.
    # Это создаст логический холст 1000x900, который будет аппаратно масштабироваться.
    base_flags = pygame.SCALED
    
    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), base_flags)
    pygame.display.set_caption("Ball Decision Arena v1.0")
    
    clock = pygame.time.Clock()
    state_manager = StateManager()
    
    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0
        
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                running = False
                
            # Обработка события переключения экрана из системных кнопок
            elif event.type == pygame.USEREVENT + 1:
                is_fullscreen = not is_fullscreen
                if is_fullscreen:
                    # Включаем полный экран поверх масштабирования (комбинируем через «|»)
                    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.FULLSCREEN | pygame.SCALED)
                else:
                    # Возвращаем обычный оконный режим с сохранением масштабирования
                    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), base_flags)
        
        state_manager.handle_events(events)
        state_manager.update(dt)
        
        screen.fill(BG_COLOR)
        state_manager.draw(screen)
        
        pygame.display.flip()
        
        if state_manager.should_quit:
            running = False

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
